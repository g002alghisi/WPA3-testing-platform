# Test Comment

## General information

- Date:       2023-12-29 17:24:13
- Device:     Raspberry_Pi_4_iwd
- Script:     Test/Src/test_p_wpa3.sh
- Result:     Good

## Comment

Perfect.

## Test script

```bash
#!/bin/bash
#set -x  # Debug mode


# Launch the AP
$ap_ui_path -c p_wpa3 -L $test_ui_log_tmp_dir

```
