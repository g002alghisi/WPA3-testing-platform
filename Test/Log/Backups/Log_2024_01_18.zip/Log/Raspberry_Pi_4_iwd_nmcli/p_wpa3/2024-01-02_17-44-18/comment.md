# Test Comment

## General information

- Date:       2024-01-02 17:44:18
- Device:     Raspberry_Pi_4_iwd_nmcli
- Script:     Test/Src/test_p_wpa3.sh
- Result:     Good

## Comment

Ok.

## Test script

```bash
#!/bin/bash
#set -x  # Debug mode


# Launch the AP
$ap_ui_path -c p_wpa3 -L $test_ui_log_tmp_dir

```
